package com.telinova.tv;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;

/**
 * خلفية صور متبدّلة: تنتقل إلى الصورة التالية كل 30 ثانية بتلاشي ناعم
 * مع حركة تكبير بطيئة. تُحمَّل صورة واحدة فقط في كل مرة خارج الخيط الرئيسي.
 */
public class SlideshowView extends FrameLayout {
    public static final long INTERVAL_MS = 30000L;
    private static final long FADE_MS = 1600L;

    private static final int[] IMAGES = {
        R.drawable.bg_slide_1, R.drawable.bg_slide_2, R.drawable.bg_slide_3,
        R.drawable.bg_slide_4, R.drawable.bg_slide_5
    };

    private final ImageView[] layers = new ImageView[2];
    private final ObjectAnimator[] zooms = new ObjectAnimator[2];
    private final SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private int front = 0;          // الطبقة الظاهرة حالياً
    private int index;              // رقم الصورة التالية
    private boolean running, hasShown, loading;
    private int generation;         // لتجاهل نتائج التحميل القديمة

    private final Runnable next = new Runnable() {
        @Override public void run() {
            if (!running) return;
            loadAndShow();
            handler.postDelayed(this, INTERVAL_MS);
        }
    };

    public SlideshowView(Context context, SharedPreferences prefs) {
        super(context);
        this.prefs = prefs;
        this.index = Math.abs(prefs.getInt("slideIdx", 0)) % IMAGES.length;
        for (int i = 0; i < 2; i++) {
            ImageView v = new ImageView(context);
            v.setScaleType(ImageView.ScaleType.CENTER_CROP);
            v.setAlpha(0f);
            addView(v, new FrameLayout.LayoutParams(-1, -1));
            layers[i] = v;
        }
    }

    public void setRunning(boolean value) {
        if (value == running) return;
        running = value;
        handler.removeCallbacks(next);
        if (value) {
            for (int i = 0; i < 2; i++) if (zooms[i] != null && zooms[i].isPaused()) zooms[i].resume();
            if (!hasShown) loadAndShow();
            handler.postDelayed(next, INTERVAL_MS);
        } else {
            for (int i = 0; i < 2; i++) if (zooms[i] != null) zooms[i].pause();
        }
    }

    @Override protected void onDetachedFromWindow() {
        generation++;
        handler.removeCallbacks(next);
        for (ImageView v : layers) v.animate().cancel();
        for (int i = 0; i < 2; i++) if (zooms[i] != null) zooms[i].cancel();
        super.onDetachedFromWindow();
    }

    private void loadAndShow() {
        if (loading) return;
        loading = true;
        final int res = IMAGES[index];
        final int gen = generation;
        index = (index + 1) % IMAGES.length;
        prefs.edit().putInt("slideIdx", index).apply();
        new Thread(new Runnable() {
            @Override public void run() {
                Bitmap bmp = null;
                try {
                    BitmapFactory.Options o = new BitmapFactory.Options();
                    o.inPreferredConfig = Bitmap.Config.ARGB_8888;
                    bmp = BitmapFactory.decodeResource(getResources(), res, o);
                } catch (Exception e) {
                    bmp = null;
                } catch (OutOfMemoryError e) {
                    bmp = null;
                }
                final Bitmap result = bmp;
                handler.post(new Runnable() {
                    @Override public void run() {
                        loading = false;
                        if (gen != generation || result == null) return;
                        show(result);
                    }
                });
            }
        }).start();
    }

    private void show(Bitmap bmp) {
        final ImageView in = layers[1 - front];
        final ImageView out = layers[front];
        in.animate().cancel();
        out.animate().cancel();
        if (zooms[1 - front] != null) zooms[1 - front].cancel();
        in.setImageBitmap(bmp);
        in.setScaleX(1f);
        in.setScaleY(1f);
        in.setAlpha(0f);
        in.bringToFront();
        in.animate().alpha(1f).setDuration(hasShown ? FADE_MS : 700L).start();
        // حركة تكبير بطيئة تعطي إحساساً بالحياة طوال مدة عرض الصورة
        ObjectAnimator zoom = ObjectAnimator.ofPropertyValuesHolder(in,
            PropertyValuesHolder.ofFloat(SCALE_X, 1f, 1.07f),
            PropertyValuesHolder.ofFloat(SCALE_Y, 1f, 1.07f));
        zoom.setDuration(INTERVAL_MS + FADE_MS);
        zoom.setInterpolator(new LinearInterpolator());
        zoom.start();
        zooms[1 - front] = zoom;
        if (hasShown) {
            out.animate().alpha(0f).setDuration(FADE_MS).withEndAction(new Runnable() {
                @Override public void run() { out.setImageDrawable(null); }
            }).start();
        }
        hasShown = true;
        front = 1 - front;
    }
}
