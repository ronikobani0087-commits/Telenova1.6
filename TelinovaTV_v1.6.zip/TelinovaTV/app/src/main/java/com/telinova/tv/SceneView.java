package com.telinova.tv;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.View;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** خلفيات متحركة مرسومة بالكود: مدينة ليلية، جبال وبحيرة، غروب بحري، غابة وضباب. */
public class SceneView extends View {
    public static final String[] NAMES = {"مدينة ليلية", "جبال وبحيرة", "غروب بحري", "غابة وضباب"};
    private static final float W = 1280f;
    private static final float H = 720f;

    private static class Wave {
        Path path;
        int color;
        float speed;
    }

    private final int scene;
    private final Random rnd;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bmpPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final RectF dst = new RectF();
    private final RectF oval = new RectF();
    private Bitmap back, front;
    private boolean running;

    private float[] starX = new float[0], starY = new float[0], starR = new float[0], starS = new float[0], starP = new float[0];
    private float[] cloudY = new float[0], cloudS = new float[0], cloudV = new float[0], cloudO = new float[0];
    private float[] shX = new float[0], shY = new float[0], shW = new float[0], shS = new float[0], shP = new float[0];
    private float[] ffX = new float[0], ffY = new float[0], ffR = new float[0], ffS = new float[0], ffP = new float[0];
    private final List<float[]> winList = new ArrayList<float[]>();
    private final List<Wave> waves = new ArrayList<Wave>();
    private Paint mistPaint;
    private int cloudColor;

    public SceneView(Context context, int sceneIndex) {
        super(context);
        scene = (sceneIndex >= 0 && sceneIndex < NAMES.length) ? sceneIndex : 0;
        rnd = new Random(1000 + scene * 17);
        try {
            back = Bitmap.createBitmap(1280, 720, Bitmap.Config.ARGB_8888);
            front = Bitmap.createBitmap(1280, 720, Bitmap.Config.ARGB_8888);
            Canvas cb = new Canvas(back);
            Canvas cf = new Canvas(front);
            if (scene == 0) buildCity(cb, cf);
            else if (scene == 1) buildMountains(cb, cf);
            else if (scene == 2) buildSea(cb, cf);
            else buildForest(cb, cf);
        } catch (OutOfMemoryError e) {
            back = null;
            front = null;
        }
    }

    public void setRunning(boolean value) {
        boolean start = value && !running;
        running = value;
        if (start) postInvalidateDelayed(40);
    }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (running) postInvalidateDelayed(40);
    }

    // ---------- أدوات الرسم ----------
    private float r(float a, float b) { return a + rnd.nextFloat() * (b - a); }

    private void sky(Canvas c, int[] cols, float[] pos) {
        paint.setShader(new LinearGradient(0f, 0f, 0f, H, cols, pos, Shader.TileMode.CLAMP));
        c.drawRect(0f, 0f, W, H, paint);
        paint.setShader(null);
    }

    private void glow(Canvas c, float x, float y, float rad, int color) {
        paint.setShader(new RadialGradient(x, y, rad, color, color & 0x00FFFFFF, Shader.TileMode.CLAMP));
        c.drawCircle(x, y, rad, paint);
        paint.setShader(null);
    }

    private void disc(Canvas c, float x, float y, float rad, int color) {
        paint.setColor(color);
        c.drawCircle(x, y, rad, paint);
    }

    private void makeStars(int n, float ymax) {
        starX = new float[n]; starY = new float[n]; starR = new float[n]; starS = new float[n]; starP = new float[n];
        for (int i = 0; i < n; i++) {
            starX[i] = r(0f, W); starY[i] = r(0f, ymax); starR[i] = r(0.6f, 1.9f);
            starS[i] = r(0.6f, 2.0f); starP[i] = r(0f, 6.28f);
        }
    }

    private void makeClouds(int n, float ymin, float ymax, int color) {
        cloudColor = color;
        cloudY = new float[n]; cloudS = new float[n]; cloudV = new float[n]; cloudO = new float[n];
        for (int i = 0; i < n; i++) {
            cloudY[i] = r(ymin, ymax); cloudS[i] = r(0.7f, 1.6f); cloudV[i] = r(8f, 20f); cloudO[i] = r(0f, 1900f);
        }
    }

    private void makeShimmer(int n, float xmin, float xmax, float ytop, float step, float wmin, float wmax) {
        shX = new float[n]; shY = new float[n]; shW = new float[n]; shS = new float[n]; shP = new float[n];
        for (int i = 0; i < n; i++) {
            shX[i] = r(xmin, xmax); shY[i] = ytop + i * step; shW[i] = r(wmin, wmax);
            shS[i] = r(0.4f, 1.1f); shP[i] = r(0f, 6.28f);
        }
    }

    private void skyline(Canvas c, float base, float hmin, float hmax, float wmin, float wmax, int color, boolean windows) {
        float x = -20f;
        while (x < 1300f) {
            float w = r(wmin, wmax);
            float h = r(hmin, hmax);
            paint.setColor(color);
            c.drawRect(x, base - h, x + w, base + 4f, paint);
            if (rnd.nextFloat() < 0.22f) c.drawRect(x + w / 2f - 2f, base - h - 34f, x + w / 2f + 2f, base - h, paint);
            if (windows) {
                for (float wy = base - h + 16f; wy < base - 14f; wy += 22f) {
                    for (float wx = x + 10f; wx < x + w - 14f; wx += 16f) {
                        float q = rnd.nextFloat();
                        if (q < 0.05f) {
                            winList.add(new float[]{wx, wy, r(3f, 8f), r(0f, 6.28f)});
                        } else if (q < 0.32f) {
                            paint.setColor(q < 0.16f ? 0xD9FFD98A : 0xD9FFB35C);
                            c.drawRect(wx, wy, wx + 7f, wy + 10f, paint);
                        }
                    }
                }
            }
            x += w + 2f + r(0f, 6f);
        }
    }

    private void ridge(Canvas c, float base, float amp, int color, float ph) {
        Path p = new Path();
        p.moveTo(0f, H);
        p.lineTo(0f, base);
        for (float x = 0f; x <= W; x += 32f) {
            float y = base - amp * (0.55f + 0.35f * (float) Math.sin(x * 0.004f + ph) + 0.25f * (float) Math.sin(x * 0.011f + ph * 2f)) - rnd.nextFloat() * amp * 0.22f;
            p.lineTo(x, y);
        }
        p.lineTo(W, H);
        p.close();
        paint.setColor(color);
        c.drawPath(p, paint);
    }

    private void pines(Canvas c, float base, float hmin, float hmax, float wmin, float wmax, int color, float x0, float x1) {
        paint.setColor(color);
        float x = x0;
        while (x < x1) {
            float w = r(wmin, wmax);
            float h = r(hmin, hmax);
            Path p = new Path();
            p.moveTo(x, base);
            p.lineTo(x + w / 2f, base - h);
            p.lineTo(x + w, base);
            p.close();
            c.drawPath(p, paint);
            x += w * 0.55f + r(0f, 10f);
        }
        c.drawRect(x0, base - 2f, x1, H, paint);
    }

    private void addWave(float y, float a, int color, float speed) {
        Path p = new Path();
        p.moveTo(0f, y);
        for (int k = 0; k < 16; k++) {
            float cxp = 160f * k + 80f;
            float cyp = (k % 2 == 0) ? y - a : y + a;
            p.quadTo(cxp, cyp, 160f * (k + 1), y);
        }
        p.lineTo(2560f, H);
        p.lineTo(0f, H);
        p.close();
        Wave w = new Wave();
        w.path = p;
        w.color = color;
        w.speed = speed;
        waves.add(w);
    }

    // ---------- بناء المشاهد ----------
    private void buildCity(Canvas cb, Canvas cf) {
        sky(cb, new int[]{0xFF070B25, 0xFF1B1650, 0xFF8A3F6E}, new float[]{0f, 0.55f, 1f});
        glow(cb, 1010f, 170f, 150f, 0x80FDF3D0);
        disc(cb, 1010f, 170f, 44f, 0xFFFDF3D0);
        makeStars(70, 380f);
        makeClouds(4, 140f, 330f, 0x10FFFFFF);
        skyline(cf, 720f, 150f, 300f, 34f, 70f, 0xFF1D1550, false);
        skyline(cf, 720f, 240f, 430f, 56f, 110f, 0xFF0A0720, true);
    }

    private void buildMountains(Canvas cb, Canvas cf) {
        sky(cb, new int[]{0xFF16244A, 0xFFD9735A, 0xFFFFD29A}, new float[]{0f, 0.55f, 1f});
        glow(cb, 640f, 420f, 260f, 0xB3FFF1C9);
        disc(cb, 640f, 420f, 62f, 0xFFFFF1C9);
        makeClouds(4, 120f, 300f, 0x2EFFE6C8);
        ridge(cf, 470f, 150f, 0xFF7A5A8F, 0f);
        ridge(cf, 500f, 150f, 0xFF4A3A73, 2f);
        ridge(cf, 530f, 130f, 0xFF251C45, 4f);
        paint.setShader(new LinearGradient(0f, 548f, 0f, H, 0xBFF0A070, 0xFF14213D, Shader.TileMode.CLAMP));
        cf.drawRect(0f, 548f, W, H, paint);
        paint.setShader(null);
        pines(cf, 720f, 120f, 260f, 40f, 70f, 0xFF0C0A1E, -30f, 330f);
        pines(cf, 720f, 120f, 260f, 40f, 70f, 0xFF0C0A1E, 950f, 1300f);
        makeShimmer(14, 380f, 860f, 560f, 11f, 90f, 280f);
    }

    private void buildSea(Canvas cb, Canvas cf) {
        sky(cb, new int[]{0xFF2B1055, 0xFFD2486E, 0xFFFFB36B}, new float[]{0f, 0.55f, 1f});
        glow(cb, 640f, 470f, 300f, 0x99FFE2A8);
        disc(cb, 640f, 470f, 112f, 0xFFFFE2A8);
        makeClouds(3, 120f, 300f, 0x33FFC8B4);
        skyline(cf, 470f, 24f, 90f, 18f, 44f, 0xFF3A1C4F, false);
        paint.setShader(new LinearGradient(0f, 470f, 0f, H, new int[]{0xFFFF9A6B, 0xFF7A3A7A, 0xFF1F1043}, new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
        cf.drawRect(0f, 470f, W, H, paint);
        paint.setShader(null);
        makeShimmer(12, 520f, 760f, 482f, 17f, 70f, 230f);
        addWave(540f, 16f, 0x59281046, 80f);
        addWave(600f, 22f, 0x80190A37, 60f);
        addWave(670f, 26f, 0xB30E0624, 45f);
    }

    private void buildForest(Canvas cb, Canvas cf) {
        sky(cb, new int[]{0xFF04150F, 0xFF0F3B2B, 0xFF2A6B4C}, new float[]{0f, 0.6f, 1f});
        glow(cb, 300f, 130f, 130f, 0x66DFFFE9);
        disc(cb, 300f, 130f, 38f, 0xFFEAFFF1);
        makeStars(40, 260f);
        pines(cf, 560f, 140f, 260f, 50f, 90f, 0xFF0D3A2B, -30f, 1300f);
        pines(cf, 640f, 170f, 320f, 60f, 110f, 0xFF072419, -30f, 1300f);
        pines(cf, 720f, 220f, 400f, 70f, 130f, 0xFF030F0A, -30f, 1300f);
        mistPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mistPaint.setShader(new RadialGradient(0f, 0f, 460f, 0x59CFEEDD, 0x00CFEEDD, Shader.TileMode.CLAMP));
        int n = 26;
        ffX = new float[n]; ffY = new float[n]; ffR = new float[n]; ffS = new float[n]; ffP = new float[n];
        for (int i = 0; i < n; i++) {
            ffX[i] = r(0f, W); ffY[i] = r(380f, 700f); ffR[i] = r(2f, 4f); ffS[i] = r(0.8f, 2f); ffP[i] = r(0f, 6.28f);
        }
    }

    // ---------- الرسم المتحرك ----------
    @Override protected void onDraw(Canvas canvas) {
        float w = getWidth();
        float h = getHeight();
        if (w <= 0f || h <= 0f) return;
        double t = SystemClock.uptimeMillis() / 1000.0;
        dst.set(0f, 0f, w, h);
        if (back != null) canvas.drawBitmap(back, null, dst, bmpPaint);
        else canvas.drawColor(0xFF07111F);
        canvas.save();
        canvas.scale(w / W, h / H);
        drawBack(canvas, t);
        canvas.restore();
        if (front != null) canvas.drawBitmap(front, null, dst, bmpPaint);
        canvas.save();
        canvas.scale(w / W, h / H);
        drawFront(canvas, t);
        canvas.restore();
        if (running) postInvalidateDelayed(40);
    }

    private void drawBack(Canvas c, double t) {
        for (int i = 0; i < starX.length; i++) {
            float a = 0.5f + 0.5f * (float) Math.sin(t * starS[i] + starP[i]);
            paint.setColor(Color.WHITE);
            paint.setAlpha((int) (60 + 195 * a));
            c.drawCircle(starX[i], starY[i], starR[i], paint);
        }
        if (cloudY.length > 0) {
            paint.setColor(cloudColor);
            for (int i = 0; i < cloudY.length; i++) {
                float x = (float) ((cloudO[i] + t * cloudV[i]) % 1900.0) - 420f;
                float y = cloudY[i];
                float s = cloudS[i];
                oval.set(x - 120f * s, y - 22f * s, x + 120f * s, y + 22f * s);
                c.drawOval(oval, paint);
                oval.set(x - 120f * s, y - 38f * s, x, y + 6f * s);
                c.drawOval(oval, paint);
                oval.set(x - 40f * s, y - 52f * s, x + 100f * s, y);
                c.drawOval(oval, paint);
            }
        }
    }

    private void drawFront(Canvas c, double t) {
        for (float[] wn : winList) {
            float a = 0.5f + 0.5f * (float) Math.sin(t * 6.28 / wn[2] + wn[3]);
            paint.setColor(0xFFFFD98A);
            paint.setAlpha((int) (26 + 200 * a));
            c.drawRect(wn[0], wn[1], wn[0] + 7f, wn[1] + 10f, paint);
        }
        for (int i = 0; i < shX.length; i++) {
            float a = 0.5f + 0.5f * (float) Math.sin(t * shS[i] + shP[i]);
            float x = shX[i] + 50f * (float) Math.sin(t * shS[i] * 0.6 + shP[i]);
            paint.setColor(scene == 1 ? 0xFFFFE6C0 : 0xFFFFE2A8);
            paint.setAlpha((int) (50 + 160 * a));
            oval.set(x, shY[i], x + shW[i], shY[i] + 3f);
            c.drawRoundRect(oval, 1.5f, 1.5f, paint);
        }
        for (Wave wv : waves) {
            float off = (float) ((t * wv.speed) % 1280.0);
            c.save();
            c.translate(-off, 0f);
            paint.setColor(wv.color);
            c.drawPath(wv.path, paint);
            c.restore();
        }
        if (mistPaint != null) {
            float m1 = (float) ((t * 14.0 + 300.0) % 2100.0) - 420f;
            float m2 = (float) ((t * 22.0 + 1100.0) % 2100.0) - 420f;
            c.save();
            c.translate(m1, 540f);
            c.scale(1f, 0.11f);
            c.drawCircle(0f, 0f, 460f, mistPaint);
            c.restore();
            c.save();
            c.translate(m2, 620f);
            c.scale(1f, 0.11f);
            c.drawCircle(0f, 0f, 460f, mistPaint);
            c.restore();
        }
        for (int i = 0; i < ffX.length; i++) {
            float a = 0.5f + 0.5f * (float) Math.sin(t * ffS[i] + ffP[i]);
            float x = ffX[i] + (float) Math.sin(t * 0.4 + ffP[i]) * 30f;
            float y = ffY[i] + (float) Math.cos(t * 0.3 + ffP[i]) * 24f;
            paint.setColor(0xFFD7FF8A);
            paint.setAlpha((int) (40 + 215 * a));
            c.drawCircle(x, y, ffR[i], paint);
            paint.setAlpha((int) (10 + 40 * a));
            c.drawCircle(x, y, ffR[i] * 3.5f, paint);
        }
    }
}
