package com.telinova.tv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int BG_PICK = 21;
    private static final int TEAL = Color.rgb(84, 214, 200);

    private static final String[] CITY_NAMES = {"الرياض", "جدة", "مكة المكرمة", "المدينة المنورة", "الدمام",
        "دبي", "أبوظبي", "الدوحة", "الكويت", "المنامة", "مسقط", "القاهرة", "الإسكندرية", "بغداد", "أربيل",
        "عمّان", "دمشق", "بيروت", "صنعاء", "عدن", "الخرطوم", "طرابلس", "تونس", "الجزائر", "الدار البيضاء", "الرباط"};
    private static final double[][] CITY_LL = {
        {24.71, 46.68}, {21.49, 39.19}, {21.39, 39.86}, {24.47, 39.61}, {26.43, 50.10},
        {25.20, 55.27}, {24.45, 54.38}, {25.29, 51.53}, {29.38, 47.99}, {26.23, 50.59}, {23.59, 58.41},
        {30.04, 31.24}, {31.20, 29.92}, {33.31, 44.37}, {36.19, 44.01}, {31.95, 35.93}, {33.51, 36.29},
        {33.89, 35.50}, {15.37, 44.19}, {12.78, 45.04}, {15.50, 32.56}, {32.89, 13.19}, {36.81, 10.18},
        {36.75, 3.06}, {33.57, -7.59}, {34.02, -6.84}};
    private static final String[] DAY_NAMES = {"الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"};

    private static class Entry {
        String label;
        String pkg;
        Drawable icon;
        Drawable banner;
        Bitmap blur;
        boolean system;
        int color;
    }

    private SharedPreferences prefs;
    private float uiScale = 1f;
    private LinearLayout root, content;
    private SceneView sceneView;
    private SlideshowView slideshow;
    private TextView clockTime, clockAmPm, clockDate;
    private TextView wIcon, wTemp, wDesc, wCity;
    private final TextView[] dName = new TextView[3];
    private final TextView[] dIcon = new TextView[3];
    private final TextView[] dRange = new TextView[3];

    private boolean focusMode, lightMode, resumed, appsDirty = true, firstFocusDone;
    private String bgMode = "slides";
    private int bgScene = 0;
    private Bitmap wallpaperBitmap;
    private String lastFocusKey;
    private List<Entry> entries;
    private BroadcastReceiver pkgReceiver;

    private boolean hasWeather, weatherFailed;
    private int curTemp, curCode;
    private final int[] dCode = new int[3];
    private final int[] dMax = new int[3];
    private final int[] dMin = new int[3];
    private final String[] dLabel = new String[3];

    private final SimpleDateFormat timeFmt = new SimpleDateFormat("h:mm", Locale.ENGLISH);
    private final SimpleDateFormat ampmFmt = new SimpleDateFormat("a", Locale.ENGLISH);
    private final SimpleDateFormat dateFmt = new SimpleDateFormat("EEEE, MMMM d", Locale.ENGLISH);

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            updateClock();
            handler.postDelayed(this, 15000);
        }
    };

    private boolean light() { return lightMode; }
    private int cardColor() { return light() ? 0xffffffff : Color.argb(220, 20, 38, 58); }
    private int focusColor() { return light() ? 0xffcdeeea : 0xff20535a; }
    private int textMain() { return light() ? 0xff0b1b2b : Color.rgb(245, 248, 252); }
    private int textSub() { return light() ? 0xff4a5f73 : 0xffd3deea; }
    private int accent() { return light() ? 0xff0b7f74 : TEAL; }
    private int widgetColor() { return light() ? Color.argb(235, 255, 255, 255) : Color.argb(110, 6, 12, 26); }

    private int dp(int v) { return Math.round(v * uiScale); }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        uiScale = Math.max(dm.widthPixels, dm.heightPixels) / 1280f;
        prefs = getSharedPreferences("telinova", MODE_PRIVATE);
        focusMode = prefs.getBoolean("focusMode", false);
        lightMode = prefs.getBoolean("lightMode", false);
        bgMode = prefs.getString("bgMode", "slides");
        bgScene = prefs.getInt("bgScene", 0);
        // تحديث 1.6: تفعيل خلفية الصور المتبدلة مرة واحدة للنسخ المثبتة سابقاً
        if (prefs.getInt("bgVer", 0) < 6) {
            bgMode = "slides";
            lightMode = false;
            prefs.edit().putString("bgMode", "slides").putBoolean("lightMode", false).putInt("bgVer", 6).apply();
        }
        for (int i = 0; i < 3; i++) dLabel[i] = "";
        String cached = prefs.getString("wjson", null);
        if (cached != null && prefs.getInt("city", -1) >= 0) parseWeather(cached);

        pkgReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) {
                appsDirty = true;
                if (resumed) renderApps();
            }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addAction(Intent.ACTION_PACKAGE_CHANGED);
        f.addDataScheme("package");
        registerReceiver(pkgReceiver, f);

        rebuild();
        if ("photo".equals(bgMode)) loadSavedPhoto();
    }

    @Override protected void onResume() {
        super.onResume();
        resumed = true;
        if (sceneView != null) sceneView.setRunning(true);
        if (slideshow != null) slideshow.setRunning(true);
        handler.removeCallbacks(tick);
        handler.post(tick);
        renderApps();
        long age = System.currentTimeMillis() - prefs.getLong("weatherAt", 0);
        if (prefs.getInt("city", -1) >= 0 && age > 30L * 60L * 1000L) fetchWeather();
    }

    @Override protected void onPause() {
        resumed = false;
        if (sceneView != null) sceneView.setRunning(false);
        if (slideshow != null) slideshow.setRunning(false);
        handler.removeCallbacks(tick);
        super.onPause();
    }

    @Override protected void onDestroy() {
        try { unregisterReceiver(pkgReceiver); } catch (Exception ignored) {}
        super.onDestroy();
    }

    @Override public void onBackPressed() { }

    private void rebuild() {
        buildUI();
        renderApps();
        updateClock();
        updateWeatherView();
    }

    // ---------- أدوات الواجهة ----------
    private GradientDrawable shape(int color, int radiusDp, boolean focused) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        if (focused) d.setStroke(dp(2), accent());
        else d.setStroke(dp(1), Color.argb(40, 255, 255, 255));
        return d;
    }

    private TextView tv(String value, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, size * uiScale);
        t.setTextColor(color);
        t.setIncludeFontPadding(false);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void addControl(LinearLayout row, String label, final Runnable action) {
        final Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_PX, 17 * uiScale);
        b.setTextColor(textMain());
        b.setFocusable(true);
        b.setBackground(shape(cardColor(), 14, false));
        b.setPadding(dp(20), dp(6), dp(20), dp(6));
        b.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View v, boolean hasFocus) {
                v.setBackground(shape(hasFocus ? focusColor() : cardColor(), 14, hasFocus));
            }
        });
        b.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { action.run(); }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(50));
        lp.setMarginEnd(dp(10));
        row.addView(b, lp);
    }

    private String greeting() {
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (h < 5) return "ليلة هادئة";
        if (h < 12) return "صباح الخير";
        if (h < 18) return "طاب يومك";
        return "مساء الخير";
    }

    private View scrim(boolean top) {
        View v = new View(this);
        int[] cols = top ? new int[]{0x99000000, 0x00000000} : new int[]{0x00000000, 0xB3000000};
        v.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, cols));
        return v;
    }

    private void buildUI() {
        FrameLayout frame = new FrameLayout(this);
        frame.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        sceneView = null;
        slideshow = null;
        boolean decorated = false;
        if (lightMode) {
            frame.setBackgroundColor(0xffeaf0f6);
        } else if ("slides".equals(bgMode)) {
            frame.setBackgroundColor(Color.rgb(7, 17, 31));
            slideshow = new SlideshowView(this, prefs);
            frame.addView(slideshow, new FrameLayout.LayoutParams(-1, -1));
            slideshow.setRunning(resumed);
            decorated = true;
        } else if ("scene".equals(bgMode)) {
            frame.setBackgroundColor(Color.rgb(7, 17, 31));
            sceneView = new SceneView(this, bgScene);
            sceneView.setRunning(resumed);
            frame.addView(sceneView, new FrameLayout.LayoutParams(-1, -1));
            decorated = true;
        } else if ("photo".equals(bgMode) && wallpaperBitmap != null) {
            frame.setBackgroundColor(Color.rgb(7, 17, 31));
            ImageView bg = new ImageView(this);
            bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
            bg.setImageBitmap(wallpaperBitmap);
            frame.addView(bg, new FrameLayout.LayoutParams(-1, -1));
            decorated = true;
        } else {
            frame.setBackgroundColor(Color.rgb(7, 17, 31));
        }
        if (decorated) {
            frame.addView(scrim(true), new FrameLayout.LayoutParams(-1, dp(340), Gravity.TOP));
            frame.addView(scrim(false), new FrameLayout.LayoutParams(-1, dp(340), Gravity.BOTTOM));
        }
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(44), dp(24), dp(44), dp(8));
        frame.addView(root, new FrameLayout.LayoutParams(-1, -1));
        setContentView(frame);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.addView(buildWeatherWidget(), new LinearLayout.LayoutParams(dp(560), -2));
        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView hello = tv(greeting(), 30, textMain(), true);
        hello.setGravity(Gravity.CENTER);
        TextView brand = tv("تيلينوفا TV", 18, textSub(), false);
        brand.setGravity(Gravity.CENTER);
        brand.setPadding(0, dp(6), 0, 0);
        mid.addView(hello, new LinearLayout.LayoutParams(-1, -2));
        mid.addView(brand, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(0, -2, 1f);
        mlp.topMargin = dp(40);
        header.addView(mid, mlp);
        header.addView(buildClockWidget(), new LinearLayout.LayoutParams(-2, -2));
        root.addView(header, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        controls.setPadding(0, dp(14), 0, dp(2));
        addControl(controls, "الإعدادات", new Runnable() { @Override public void run() { openSettings(); } });
        addControl(controls, "الخلفية", new Runnable() { @Override public void run() { showBackgroundDialog(); } });
        addControl(controls, "المفضلة", new Runnable() { @Override public void run() { showFavoritesDialog(); } });
        addControl(controls, "المظهر", new Runnable() { @Override public void run() { showThemeDialog(); } });
        addControl(controls, "وضع التركيز", new Runnable() { @Override public void run() { toggleFocusMode(); } });
        TextView hint = tv("اضغط مطولاً على أي تطبيق: مفضلة، معلومات، حذف", 15, textSub(), false);
        hint.setPadding(dp(14), 0, 0, 0);
        controls.addView(hint);
        root.addView(controls, new LinearLayout.LayoutParams(-1, -2));

        ScrollView scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setClipChildren(false);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setClipChildren(false);
        content.setPadding(0, dp(2), 0, dp(24));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
    }

    private View buildClockWidget() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.END);
        box.setPadding(dp(26), dp(16), dp(26), dp(16));
        box.setBackground(shape(widgetColor(), 24, false));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.BOTTOM);
        clockTime = tv("0:00", 104, textMain(), false);
        clockAmPm = tv("AM", 30, textSub(), true);
        clockAmPm.setPadding(dp(10), 0, 0, dp(14));
        row.addView(clockTime);
        row.addView(clockAmPm);
        box.addView(row);

        clockDate = tv("", 24, textSub(), false);
        clockDate.setPadding(0, dp(4), 0, 0);
        box.addView(clockDate);
        return box;
    }

    private View buildWeatherWidget() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(24), dp(14), dp(24), dp(14));
        box.setFocusable(true);
        box.setClickable(true);
        box.setBackground(shape(widgetColor(), 24, false));
        box.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showWeatherDialog(); }
        });
        box.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View v, boolean hasFocus) {
                v.setBackground(shape(hasFocus ? focusColor() : widgetColor(), 24, hasFocus));
            }
        });

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        wIcon = tv("\u2601", 72, textMain(), false);
        wTemp = tv("--\u00B0", 84, textMain(), false);
        wTemp.setPadding(dp(14), 0, dp(18), 0);
        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        wDesc = tv("", 28, textMain(), true);
        wCity = tv("", 20, textSub(), false);
        wCity.setPadding(0, dp(4), 0, 0);
        info.addView(wDesc);
        info.addView(wCity);
        top.addView(wIcon);
        top.addView(wTemp);
        top.addView(info);
        box.addView(top);

        LinearLayout days = new LinearLayout(this);
        days.setOrientation(LinearLayout.HORIZONTAL);
        days.setPadding(0, dp(10), 0, 0);
        for (int i = 0; i < 3; i++) {
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setGravity(Gravity.CENTER_HORIZONTAL);
            dName[i] = tv("", 18, textSub(), true);
            dIcon[i] = tv("", 30, textMain(), false);
            dIcon[i].setPadding(0, dp(2), 0, dp(2));
            dRange[i] = tv("", 18, textMain(), false);
            col.addView(dName[i]);
            col.addView(dIcon[i]);
            col.addView(dRange[i]);
            days.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        box.addView(days, new LinearLayout.LayoutParams(-1, -2));
        return box;
    }

    // ---------- الإجراءات ----------
    private void openSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        } catch (Exception e) {
            Toast.makeText(this, "تعذر فتح الإعدادات", Toast.LENGTH_SHORT).show();
        }
    }

    private void toggleFocusMode() {
        focusMode = !focusMode;
        prefs.edit().putBoolean("focusMode", focusMode).apply();
        Toast.makeText(this, focusMode ? "تم تشغيل وضع التركيز (بطاقات أكبر)" : "تم إيقاف وضع التركيز", Toast.LENGTH_SHORT).show();
        renderApps();
    }

    private void showThemeDialog() {
        String[] items = {"الوضع الداكن", "الوضع الفاتح"};
        new AlertDialog.Builder(this).setTitle("المظهر").setSingleChoiceItems(items, lightMode ? 1 : 0, new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface d, int which) {
                boolean wantLight = (which == 1);
                d.dismiss();
                if (wantLight != lightMode) {
                    lightMode = wantLight;
                    prefs.edit().putBoolean("lightMode", lightMode).apply();
                    if (lightMode) Toast.makeText(MainActivity.this, "المظهر الفاتح يخفي الخلفية", Toast.LENGTH_SHORT).show();
                    rebuild();
                }
            }
        }).show();
    }

    // ---------- الخلفيات ----------
    private void showBackgroundDialog() {
        final int n = SceneView.NAMES.length;
        String[] items = new String[n + 3];
        items[0] = "صور متبدلة (تتغير كل 30 ثانية)";
        for (int i = 0; i < n; i++) items[i + 1] = SceneView.NAMES[i];
        items[n + 1] = "صورة من الجهاز";
        items[n + 2] = "لون سادة (بدون خلفية)";
        new AlertDialog.Builder(this).setTitle("اختر الخلفية").setItems(items, new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface d, int which) {
                if (which == 0) applyBg("slides", bgScene, null);
                else if (which <= n) applyBg("scene", which - 1, null);
                else if (which == n + 1) pickWallpaper();
                else applyBg("none", bgScene, null);
            }
        }).show();
    }

    private void applyBg(String mode, int scene, Bitmap bmp) {
        bgMode = mode;
        bgScene = scene;
        wallpaperBitmap = bmp;
        lightMode = false;
        prefs.edit().putString("bgMode", mode).putInt("bgScene", scene).putBoolean("lightMode", false).apply();
        rebuild();
    }

    private void pickWallpaper() {
        Intent open = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        open.addCategory(Intent.CATEGORY_OPENABLE);
        open.setType("image/*");
        try {
            startActivityForResult(open, BG_PICK);
            return;
        } catch (ActivityNotFoundException e) {
        }
        Intent get = new Intent(Intent.ACTION_GET_CONTENT);
        get.addCategory(Intent.CATEGORY_OPENABLE);
        get.setType("image/*");
        try {
            startActivityForResult(get, BG_PICK);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "لا يوجد تطبيق لاختيار الصور على هذا التلفاز. اختر إحدى الخلفيات المتحركة.", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == BG_PICK && resultCode == RESULT_OK && data != null && data.getData() != null) {
            savePhotoFromUri(data.getData());
        }
    }

    private Bitmap decodeScaled(InputStream in1, InputStream in2) {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeStream(in1, null, o);
        int sample = 1;
        while (o.outWidth / (sample * 2) >= 1920 && o.outHeight / (sample * 2) >= 1080) sample *= 2;
        o.inJustDecodeBounds = false;
        o.inSampleSize = sample;
        return BitmapFactory.decodeStream(in2, null, o);
    }

    private void savePhotoFromUri(final Uri uri) {
        new Thread(new Runnable() {
            @Override public void run() {
                Bitmap bmp = null;
                try {
                    InputStream a = getContentResolver().openInputStream(uri);
                    InputStream b = getContentResolver().openInputStream(uri);
                    try { bmp = decodeScaled(a, b); }
                    finally { if (a != null) a.close(); if (b != null) b.close(); }
                    if (bmp != null) {
                        FileOutputStream fo = new FileOutputStream(new File(getFilesDir(), "wallpaper.jpg"));
                        try { bmp.compress(Bitmap.CompressFormat.JPEG, 90, fo); }
                        finally { fo.close(); }
                    }
                } catch (Exception e) {
                    bmp = null;
                } catch (OutOfMemoryError e) {
                    bmp = null;
                }
                final Bitmap result = bmp;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (isFinishing()) return;
                        if (result != null) applyBg("photo", bgScene, result);
                        else Toast.makeText(MainActivity.this, "تعذر تحميل الصورة. جرّب خلفية متحركة.", Toast.LENGTH_LONG).show();
                    }
                });
            }
        }).start();
    }

    private void loadSavedPhoto() {
        new Thread(new Runnable() {
            @Override public void run() {
                Bitmap bmp = null;
                try {
                    bmp = BitmapFactory.decodeFile(new File(getFilesDir(), "wallpaper.jpg").getAbsolutePath());
                } catch (Exception e) {
                    bmp = null;
                } catch (OutOfMemoryError e) {
                    bmp = null;
                }
                final Bitmap result = bmp;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (isFinishing()) return;
                        if (result != null) {
                            wallpaperBitmap = result;
                        } else {
                            bgMode = "scene";
                            bgScene = 0;
                            prefs.edit().putString("bgMode", "scene").putInt("bgScene", 0).apply();
                        }
                        rebuild();
                    }
                });
            }
        }).start();
    }

    // ---------- الطقس ----------
    private void showWeatherDialog() {
        String[] items = new String[CITY_NAMES.length + 1];
        items[0] = "تحديث الآن";
        for (int i = 0; i < CITY_NAMES.length; i++) items[i + 1] = CITY_NAMES[i];
        new AlertDialog.Builder(this).setTitle("الطقس: اختر مدينتك").setItems(items, new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface d, int which) {
                if (which > 0) {
                    prefs.edit().putInt("city", which - 1).remove("wjson").putLong("weatherAt", 0).apply();
                    hasWeather = false;
                    weatherFailed = false;
                }
                if (prefs.getInt("city", -1) < 0) {
                    Toast.makeText(MainActivity.this, "اختر مدينة أولاً", Toast.LENGTH_SHORT).show();
                    return;
                }
                updateWeatherView();
                fetchWeather();
            }
        }).show();
    }

    private String weatherDesc(int code) {
        if (code == 0) return "صافٍ";
        if (code == 1 || code == 2) return "غائم جزئياً";
        if (code == 3) return "غائم";
        if (code == 45 || code == 48) return "ضباب";
        if (code >= 51 && code <= 57) return "رذاذ";
        if (code >= 61 && code <= 67) return "مطر";
        if (code >= 71 && code <= 77) return "ثلج";
        if (code >= 80 && code <= 82) return "زخات مطر";
        if (code >= 95) return "عواصف رعدية";
        return "";
    }

    private String weatherIcon(int code) {
        if (code == 0) return "\u2600";
        if (code == 1 || code == 2) return "\u26C5";
        if (code == 3) return "\u2601";
        if (code == 45 || code == 48) return "\uD83C\uDF2B";
        if (code >= 51 && code <= 67) return "\uD83C\uDF27";
        if (code >= 71 && code <= 77) return "\u2744";
        if (code >= 80 && code <= 82) return "\uD83C\uDF26";
        if (code >= 95) return "\u26C8";
        return "\uD83C\uDF21";
    }

    private boolean parseWeather(String json) {
        try {
            JSONObject o = new JSONObject(json);
            JSONObject cur = o.getJSONObject("current");
            int t = (int) Math.round(cur.getDouble("temperature_2m"));
            int c = cur.getInt("weather_code");
            JSONObject d = o.getJSONObject("daily");
            JSONArray times = d.getJSONArray("time");
            JSONArray codes = d.getJSONArray("weather_code");
            JSONArray mx = d.getJSONArray("temperature_2m_max");
            JSONArray mn = d.getJSONArray("temperature_2m_min");
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
            Calendar cal = Calendar.getInstance();
            int n = Math.min(3, times.length());
            for (int i = 0; i < 3; i++) {
                if (i < n) {
                    dCode[i] = codes.getInt(i);
                    dMax[i] = (int) Math.round(mx.getDouble(i));
                    dMin[i] = (int) Math.round(mn.getDouble(i));
                    if (i == 0) dLabel[i] = "اليوم";
                    else if (i == 1) dLabel[i] = "غداً";
                    else {
                        cal.setTime(f.parse(times.getString(i)));
                        dLabel[i] = DAY_NAMES[cal.get(Calendar.DAY_OF_WEEK) - 1];
                    }
                } else {
                    dLabel[i] = "";
                    dCode[i] = -1;
                }
            }
            curTemp = t;
            curCode = c;
            hasWeather = true;
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void updateWeatherView() {
        if (wTemp == null) return;
        int ci = prefs.getInt("city", -1);
        if (ci < 0 || ci >= CITY_NAMES.length) {
            wIcon.setText("\u2601");
            wTemp.setText("--\u00B0");
            wDesc.setText("اختر مدينتك");
            wCity.setText("اضغط هنا لعرض الطقس");
            for (int i = 0; i < 3; i++) { dName[i].setText(""); dIcon[i].setText(""); dRange[i].setText(""); }
            return;
        }
        if (!hasWeather) {
            wIcon.setText("\u2601");
            wTemp.setText("--\u00B0");
            wDesc.setText(weatherFailed ? "تعذر التحديث" : "جارٍ التحديث");
            wCity.setText(weatherFailed ? "تأكد من الإنترنت ثم اضغط هنا" : CITY_NAMES[ci]);
            for (int i = 0; i < 3; i++) { dName[i].setText(""); dIcon[i].setText(""); dRange[i].setText(""); }
            return;
        }
        wIcon.setText(weatherIcon(curCode));
        wTemp.setText(curTemp + "\u00B0");
        wDesc.setText(weatherDesc(curCode));
        wCity.setText(CITY_NAMES[ci]);
        for (int i = 0; i < 3; i++) {
            dName[i].setText(dLabel[i]);
            if (dCode[i] < 0) { dIcon[i].setText(""); dRange[i].setText(""); }
            else {
                dIcon[i].setText(weatherIcon(dCode[i]));
                dRange[i].setText(dMax[i] + "\u00B0 / " + dMin[i] + "\u00B0");
            }
        }
    }

    private void fetchWeather() {
        final int ci = prefs.getInt("city", -1);
        if (ci < 0 || ci >= CITY_NAMES.length) return;
        new Thread(new Runnable() {
            @Override public void run() {
                String result = null;
                try {
                    String u = "https://api.open-meteo.com/v1/forecast?latitude=" + CITY_LL[ci][0]
                        + "&longitude=" + CITY_LL[ci][1]
                        + "&current=temperature_2m,weather_code"
                        + "&daily=weather_code,temperature_2m_max,temperature_2m_min"
                        + "&timezone=auto&forecast_days=3";
                    HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
                    c.setConnectTimeout(8000);
                    c.setReadTimeout(8000);
                    InputStream in = c.getInputStream();
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    byte[] buf = new byte[2048];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                    in.close();
                    result = out.toString("UTF-8");
                } catch (Exception e) {
                    result = null;
                }
                final String json = result;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (isFinishing()) return;
                        if (json != null && parseWeather(json)) {
                            weatherFailed = false;
                            prefs.edit().putString("wjson", json).putLong("weatherAt", System.currentTimeMillis()).apply();
                        } else if (!hasWeather) {
                            weatherFailed = true;
                        }
                        updateWeatherView();
                    }
                });
            }
        }).start();
    }

    private void updateClock() {
        if (clockTime == null) return;
        Date now = new Date();
        clockTime.setText(timeFmt.format(now));
        clockAmPm.setText(ampmFmt.format(now).toUpperCase(Locale.ENGLISH));
        clockDate.setText(dateFmt.format(now));
    }

    // ---------- التطبيقات ----------
    private Set<String> favorites() {
        return new HashSet<String>(prefs.getStringSet("favorites", new HashSet<String>()));
    }

    private void saveFavorites(Set<String> set) {
        prefs.edit().putStringSet("favorites", new HashSet<String>(set)).apply();
    }

    private final List<LinearLayout> rowViews = new ArrayList<LinearLayout>();

    private List<String> recents() {
        List<String> l = new ArrayList<String>();
        String s = prefs.getString("recent", "");
        if (s.length() > 0) {
            for (String p : s.split(",")) if (p.length() > 0) l.add(p);
        }
        return l;
    }

    private void pushRecent(String pkg) {
        List<String> l = recents();
        l.remove(pkg);
        l.add(0, pkg);
        while (l.size() > 8) l.remove(l.size() - 1);
        prefs.edit().putString("recent", TextUtils.join(",", l)).apply();
    }

    private List<Entry> loadEntries() {
        PackageManager pm = getPackageManager();
        List<Entry> list = new ArrayList<Entry>();
        for (ApplicationInfo ai : pm.getInstalledApplications(0)) {
            if (getPackageName().equals(ai.packageName)) continue;
            if (pm.getLaunchIntentForPackage(ai.packageName) == null) continue;
            Entry e = new Entry();
            e.pkg = ai.packageName;
            e.label = String.valueOf(pm.getApplicationLabel(ai));
            e.system = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0 && (ai.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0;
            try { e.icon = pm.getApplicationIcon(ai); } catch (Exception ignored) {}
            try { e.banner = ai.loadBanner(pm); } catch (Exception ignored) {}
            e.color = avgColor(e.icon);
            list.add(e);
        }
        Collections.sort(list, new Comparator<Entry>() {
            @Override public int compare(Entry a, Entry b) { return a.label.compareToIgnoreCase(b.label); }
        });
        return list;
    }

    private Entry findEntry(String pkg) {
        for (Entry e : entries) if (e.pkg.equals(pkg)) return e;
        return null;
    }

    private void showFavoritesDialog() {
        if (entries == null) entries = loadEntries();
        final String[] labels = new String[entries.size()];
        final boolean[] checked = new boolean[entries.size()];
        final Set<String> fav = favorites();
        for (int i = 0; i < entries.size(); i++) {
            labels[i] = entries.get(i).label;
            checked[i] = fav.contains(entries.get(i).pkg);
        }
        new AlertDialog.Builder(this).setTitle("اختر تطبيقاتك المفضلة")
            .setMultiChoiceItems(labels, checked, new DialogInterface.OnMultiChoiceClickListener() {
                @Override public void onClick(DialogInterface d, int which, boolean isChecked) {
                    String pkg = entries.get(which).pkg;
                    if (isChecked) fav.add(pkg); else fav.remove(pkg);
                    saveFavorites(fav);
                }
            })
            .setPositiveButton("تم", null)
            .setOnDismissListener(new DialogInterface.OnDismissListener() {
                @Override public void onDismiss(DialogInterface d) { renderApps(); }
            }).show();
    }

    // عدد التطبيقات في كل سطر: 4 (و3 في وضع التركيز لبطاقات أكبر)
    private int perRow() { return focusMode ? 3 : 4; }

    private int cardW() {
        int screenW = getResources().getDisplayMetrics().widthPixels;
        int avail = screenW - 2 * dp(44);
        return (avail - perRow() * dp(16)) / perRow();
    }

    private int cardH() { return cardW() * 9 / 16; }

    private LinearLayout addRow(String title) {
        if (title != null) {
            TextView h = tv(title, 24, accent(), true);
            h.setPadding(dp(8), dp(12), dp(8), dp(2));
            content.addView(h);
        }
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setClipChildren(false);
        content.addView(row, new LinearLayout.LayoutParams(-1, -2));
        rowViews.add(row);
        return row;
    }

    // يقسّم القائمة إلى أسطر، كل سطر perRow() تطبيقات
    private void addGrid(String title, List<Entry> list, String prefix, List<View> tiles) {
        int per = perRow();
        for (int i = 0; i < list.size(); i += per) {
            LinearLayout row = addRow(i == 0 ? title : null);
            for (int j = i; j < Math.min(list.size(), i + per); j++) tiles.add(addCard(row, list.get(j), prefix));
        }
    }

    private void renderApps() {
        if (content == null) return;
        String focusKey = lastFocusKey;
        View cur = getCurrentFocus();
        if (cur != null && cur.getTag() instanceof String) focusKey = (String) cur.getTag();

        if (appsDirty || entries == null) {
            entries = loadEntries();
            appsDirty = false;
        }
        content.removeAllViews();
        rowViews.clear();
        Set<String> fav = favorites();
        List<View> tiles = new ArrayList<View>();

        List<Entry> favEntries = new ArrayList<Entry>();
        for (Entry e : entries) if (fav.contains(e.pkg)) favEntries.add(e);
        if (favEntries.isEmpty()) {
            TextView h = tv("المفضلة ★", 24, accent(), true);
            h.setPadding(dp(8), dp(12), dp(8), dp(4));
            content.addView(h);
            TextView hint = tv("اضغط مطولاً على أي تطبيق لإضافته، أو استخدم زر «المفضلة» بالأعلى.", 17, textSub(), false);
            hint.setPadding(dp(8), 0, dp(8), dp(8));
            content.addView(hint);
        } else {
            addGrid("المفضلة ★", favEntries, "f:", tiles);
        }

        List<Entry> recentEntries = new ArrayList<Entry>();
        for (String p : recents()) {
            Entry e = findEntry(p);
            if (e != null) recentEntries.add(e);
        }
        if (!recentEntries.isEmpty()) {
            addGrid("آخر ما فتحته", recentEntries, "r:", tiles);
        }

        addGrid("كل التطبيقات", entries, "a:", tiles);

        View target = null;
        if (focusKey != null && focusKey.length() > 2) {
            String alt = "a:" + focusKey.substring(2);
            View fallback = null;
            for (View t : tiles) {
                if (focusKey.equals(t.getTag())) target = t;
                else if (alt.equals(t.getTag())) fallback = t;
            }
            if (target == null) target = fallback;
        }
        if (target == null && !firstFocusDone && !tiles.isEmpty()) {
            target = tiles.get(0);
        }
        if (!tiles.isEmpty()) firstFocusDone = true;
        if (target != null) target.requestFocus();
    }

    private View addCard(LinearLayout row, final Entry e, String tagPrefix) {
        final PackageManager pm = getPackageManager();
        int cw = cardW();
        int ch = cardH();
        final FrameLayout card = new FrameLayout(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(cw, ch);
        lp.setMargins(dp(8), dp(14), dp(8), dp(16));
        card.setLayoutParams(lp);
        float[] hsv = new float[3];
        Color.colorToHSV(e.color, hsv);
        float v1 = Math.max(0.40f, Math.min(0.90f, hsv[2]));
        int c1 = Color.HSVToColor(new float[]{hsv[0], Math.min(1f, hsv[1] * 0.9f + 0.05f), v1});
        int c2 = Color.HSVToColor(new float[]{hsv[0], Math.min(1f, hsv[1] * 0.9f + 0.10f), v1 * 0.45f});
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{c1, c2});
        bg.setCornerRadius(dp(18));
        card.setBackground(bg);
        card.setClipToOutline(true);
        card.setCameraDistance(dp(1300));
        card.setFocusable(true);
        card.setClickable(true);
        card.setContentDescription(e.label);
        card.setTag(tagPrefix + e.pkg);

        if (e.banner != null) {
            ImageView pic = new ImageView(this);
            pic.setScaleType(ImageView.ScaleType.CENTER_CROP);
            pic.setImageDrawable(e.banner);
            card.addView(pic, new FrameLayout.LayoutParams(-1, -1));
        } else {
            fillIcon(card, e, ch);
            TextView label = tv(e.label, focusMode ? 20 : 17, Color.WHITE, true);
            label.setGravity(Gravity.CENTER);
            label.setMaxLines(1);
            label.setEllipsize(TextUtils.TruncateAt.END);
            label.setPadding(dp(10), dp(12), dp(10), dp(6));
            label.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0x00000000, 0xB3000000}));
            card.addView(label, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
        }

        card.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Intent launch = pm.getLaunchIntentForPackage(e.pkg);
                if (launch == null) {
                    Toast.makeText(MainActivity.this, "التطبيق لم يعد متاحاً", Toast.LENGTH_SHORT).show();
                    return;
                }
                pushRecent(e.pkg);
                try { startActivity(launch); }
                catch (Exception ex) { Toast.makeText(MainActivity.this, "تعذر فتح التطبيق", Toast.LENGTH_SHORT).show(); }
            }
        });
        card.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) {
                showAppMenu(e);
                return true;
            }
        });
        card.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(final View v, boolean hasFocus) {
                if (hasFocus) {
                    GradientDrawable ring = new GradientDrawable();
                    ring.setColor(Color.TRANSPARENT);
                    ring.setStroke(dp(5), light() ? accent() : Color.WHITE);
                    ring.setCornerRadius(dp(18));
                    v.setForeground(ring);
                    if (v.getTag() instanceof String) lastFocusKey = (String) v.getTag();
                    apply3d(v);
                } else {
                    v.setForeground(null);
                    v.post(new Runnable() {
                        @Override public void run() {
                            View f = getCurrentFocus();
                            if (f == null || !(f.getTag() instanceof String)) apply3d(null);
                        }
                    });
                }
            }
        });
        row.addView(card);
        return card;
    }

    private Drawable copyOf(Drawable d) {
        if (d == null) return null;
        try {
            Drawable.ConstantState cs = d.getConstantState();
            if (cs != null) return cs.newDrawable(getResources()).mutate();
        } catch (Exception ignored) {}
        return d;
    }

    // الأيقونة تملأ المستطيل كاملاً: خلفية ممتدة بألوان الأيقونة + الشعار بكامل ارتفاع البطاقة
    private void fillIcon(FrameLayout card, Entry e, int ch) {
        Drawable ic = copyOf(e.icon);
        if (ic instanceof AdaptiveIconDrawable) {
            AdaptiveIconDrawable ad = (AdaptiveIconDrawable) ic;
            Drawable back = ad.getBackground();
            Drawable fore = ad.getForeground();
            if (back != null && fore != null) {
                ImageView b = new ImageView(this);
                b.setScaleType(ImageView.ScaleType.CENTER_CROP);
                b.setImageDrawable(back);
                card.addView(b, new FrameLayout.LayoutParams(-1, -1));
                ImageView f = new ImageView(this);
                f.setScaleType(ImageView.ScaleType.FIT_CENTER);
                f.setImageDrawable(fore);
                int size = (int) (ch * 1.32f);
                card.addView(f, new FrameLayout.LayoutParams(size, size, Gravity.CENTER));
                return;
            }
        }
        if (ic == null) return;
        if (e.blur == null) {
            try {
                Bitmap small = Bitmap.createBitmap(32, 18, Bitmap.Config.ARGB_8888);
                Canvas c = new Canvas(small);
                Drawable tmp = copyOf(e.icon);
                tmp.setBounds(0, 0, 32, 18);
                tmp.draw(c);
                e.blur = small;
            } catch (Exception ignored) {}
        }
        if (e.blur != null) {
            BitmapDrawable bd = new BitmapDrawable(getResources(), e.blur);
            bd.setFilterBitmap(true);
            ImageView b = new ImageView(this);
            b.setScaleType(ImageView.ScaleType.FIT_XY);
            b.setImageDrawable(bd);
            card.addView(b, new FrameLayout.LayoutParams(-1, -1));
        }
        ImageView f = new ImageView(this);
        f.setScaleType(ImageView.ScaleType.FIT_CENTER);
        f.setImageDrawable(ic);
        card.addView(f, new FrameLayout.LayoutParams(ch, ch, Gravity.CENTER));
    }

    private int avgColor(Drawable d) {
        if (d == null) return Color.rgb(60, 90, 140);
        try {
            Drawable.ConstantState cs = d.getConstantState();
            Drawable dd = (cs != null) ? cs.newDrawable().mutate() : d;
            Bitmap b = Bitmap.createBitmap(24, 24, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(b);
            dd.setBounds(0, 0, 24, 24);
            dd.draw(c);
            long r = 0, g = 0, bl = 0, n = 0;
            for (int x = 0; x < 24; x++) {
                for (int y = 0; y < 24; y++) {
                    int p = b.getPixel(x, y);
                    if (Color.alpha(p) < 40) continue;
                    r += Color.red(p);
                    g += Color.green(p);
                    bl += Color.blue(p);
                    n++;
                }
            }
            b.recycle();
            if (n == 0) return Color.rgb(60, 90, 140);
            return Color.rgb((int) (r / n), (int) (g / n), (int) (bl / n));
        } catch (Exception ex) {
            return Color.rgb(60, 90, 140);
        }
    }

    private void setProps(View c, float rot, float sc, float al, float tx, float z, boolean animate) {
        c.setPivotX(c.getWidth() / 2f);
        c.setPivotY(c.getHeight() / 2f);
        c.setElevation(z);
        if (animate) {
            c.animate().rotationY(rot).scaleX(sc).scaleY(sc).alpha(al).translationX(tx)
                .setDuration(280).setInterpolator(new DecelerateInterpolator(1.6f)).start();
        } else {
            c.animate().cancel();
            c.setRotationY(rot);
            c.setScaleX(sc);
            c.setScaleY(sc);
            c.setAlpha(al);
            c.setTranslationX(tx);
        }
    }

    // تنقل ثلاثي الأبعاد داخل السطر: البطاقة المحددة تبرز وتواجهك،
    // وجاراتها تميل نحوها بمنظور وتصغر قليلاً.
    private void apply3d(final View focused) { apply3d(focused, true); }

    private void apply3d(final View focused, boolean retry) {
        if (focused != null && focused.getWidth() == 0) {
            if (retry) focused.post(new Runnable() {
                @Override public void run() { if (focused.hasFocus()) apply3d(focused, false); }
            });
            return;
        }
        View parent = (focused == null) ? null : (View) focused.getParent();
        for (LinearLayout row : rowViews) {
            int n = row.getChildCount();
            int fi = (parent != null && row == parent) ? row.indexOfChild(focused) : -1;
            for (int i = 0; i < n; i++) {
                View c = row.getChildAt(i);
                if (fi < 0) { setProps(c, 0f, 1f, 1f, 0f, 0f, false); continue; }
                int d = i - fi;
                int ad = Math.abs(d);
                if (d == 0) {
                    setProps(c, 0f, 1.12f, 1f, 0f, dp(22), true);
                } else {
                    float rot = -Math.signum((float) d) * Math.min(14f, 8f + ad * 3f);
                    float sc = Math.max(0.9f, 0.97f - 0.02f * ad);
                    float al = Math.max(0.8f, 1f - 0.05f * ad);
                    float tx = Math.signum((float) d) * dp(4);
                    setProps(c, rot, sc, al, tx, Math.max(0f, dp(12) - ad * dp(3)), true);
                }
            }
        }
    }

    private void showAppMenu(final Entry e) {
        final boolean isFav = favorites().contains(e.pkg);
        String[] items = {isFav ? "إزالة من المفضلة" : "إضافة إلى المفضلة", "معلومات التطبيق", "حذف التطبيق"};
        new AlertDialog.Builder(this).setTitle(e.label).setItems(items, new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface d, int which) {
                if (which == 0) {
                    Set<String> set = favorites();
                    if (isFav) set.remove(e.pkg); else set.add(e.pkg);
                    saveFavorites(set);
                    Toast.makeText(MainActivity.this, isFav ? "أزيل من المفضلة" : "أضيف إلى المفضلة", Toast.LENGTH_SHORT).show();
                    renderApps();
                } else if (which == 1) {
                    openAppInfo(e);
                } else {
                    confirmUninstall(e);
                }
            }
        }).show();
    }

    private void openAppInfo(Entry e) {
        try {
            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + e.pkg)));
        } catch (Exception ex) {
            Toast.makeText(this, "تعذر فتح معلومات التطبيق", Toast.LENGTH_SHORT).show();
        }
    }

    private void confirmUninstall(final Entry e) {
        if (e.system) {
            Toast.makeText(this, "هذا تطبيق نظام ولا يمكن حذفه", Toast.LENGTH_LONG).show();
            return;
        }
        new AlertDialog.Builder(this).setTitle("حذف التطبيق")
            .setMessage("هل تريد حذف «" + e.label + "» من التلفاز؟")
            .setPositiveButton("حذف", new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface d, int w) {
                    try {
                        startActivity(new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + e.pkg)));
                    } catch (Exception ex) {
                        Toast.makeText(MainActivity.this, "تعذر بدء الحذف", Toast.LENGTH_SHORT).show();
                    }
                }
            })
            .setNegativeButton("إلغاء", null).show();
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            new AlertDialog.Builder(this).setTitle("تيلينوفا TV")
                .setItems(new String[]{"الإعدادات", "الخلفية", "المفضلة", "الطقس", "المظهر", "تبديل وضع التركيز", "حول التطبيق"},
                    new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) {
                            if (w == 0) openSettings();
                            else if (w == 1) showBackgroundDialog();
                            else if (w == 2) showFavoritesDialog();
                            else if (w == 3) showWeatherDialog();
                            else if (w == 4) showThemeDialog();
                            else if (w == 5) toggleFocusMode();
                            else new AlertDialog.Builder(MainActivity.this)
                                .setMessage("تيلينوفا TV — واجهة رئيسية لأندرويد 8.0 وما بعده.")
                                .setPositiveButton("حسناً", null).show();
                        }
                    }).show();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
